/*
 * NSGAII.h
 *
 *  Created on: 21 de nov de 2015
 *      Author: arthur
 */

#ifndef NSGAII_H_
#define NSGAII_H_

typedef struct Individual{
	float vehicle_trip_total_time;
	float vehicle_trip_total_distance;
	float riders_trip_total_time;
	float riders_trip_total_distance;
	float riders_unmatched;

	int rotas;//??????????
	/*O cromosomo � uma lista de rotas, onde cada rota � uma lista de v�rtices
	 * A primeira dimens�o ter� tamanho N igual ao n�mero de ve�culos dispon�veis
	 * A segunda dimens�o ter� tamanho igual ao n�mero total de v�rtices do grafo
	 * Todos as solu��es ter�o N rotas, mas cada rota pode ter uma qtd vari�vel de v�rtices
	 * O fim da lista � encontrado ao verificar que o v�rtice lido � o destino*/
	vertex*** cromossomo;
	int n;//N�mero de solu��es que dominam ind
	struct Individual* S;//Conjunto de solu��es dominadas por ind
	int Sn;//n�mero de solu��es dominadas por ind
}Individual;


typedef struct Population{
	//posi��o do front (caso essa popula��o seja um front)
	int id_front;
	Individual* list;
	int size;
}Population;

typedef struct Fronts{
	int size;//quantidade de fronts (pode ser diferente da capacidade max)
	Population* list;//Cada popula��o � um front
}Fronts;


Fronts* new_front_list(int max_capacity){
	Fronts* f = (Fronts*) calloc(sizeof(Fronts));
	f->size = 0;
	f->list = (Population*) calloc(max_capacity, sizeof(Population));
	for (int i = 0; i < max_capacity; i++){
		f->list[i]->id_front = 0;
		f->list[i]->list = calloc(max_capacity, sizeof(Individual));
	}
	return f;
}



#endif /* NSGAII_H_ */
